library globals;
int gans=0;
