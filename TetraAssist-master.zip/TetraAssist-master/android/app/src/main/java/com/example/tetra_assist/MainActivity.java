package com.example.tetra_assist;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
